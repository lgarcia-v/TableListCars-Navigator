//
//  VideoListVC.swift
//  MyTableView
//
//  Created by Field Employee on 12/9/21.
//

import UIKit

class VideoListVC: UIViewController {
    
    var tableView = UITableView()
    var videos: [Video] = []
    
    struct Cells {
        static let videoCell = "VideoCell"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Luis's Dream Cars"
        configureTableView()
        // Do any additional setup after loading the view.
    }
    
    
    func configureTableView() {
        
        view.addSubview(tableView)
        //set delegates
        setTableViewDelegates()
        //set row height
        tableView.rowHeight = 100
        //register cells
        tableView.register(VideoCell.self, forCellReuseIdentifier: Cells.videoCell)
        //set constraints
        tableView.pin(to: view)
        
    }
    
    func setTableViewDelegates() {
        tableView.delegate = self
        tableView.dataSource = self
    }

}

extension VideoListVC: UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        videos.count
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: Cells.videoCell) as! VideoCell
        
        let video = videos[indexPath.row]
        cell.set(video: video)
        
        return cell
    }
    
}

//DUMMY DATA THE IMAGES OF CARS
extension VideoListVC {
    
    func fetchData() -> [Video] {
        let car1 = Video(image: Images.ast19, title: "Aston Martin DBS Superleggera")
        let car2 = Video(image: Images.merc20, title: "Mercedes")
        let car3 = Video(image: Images.bent20, title: "Bently")
        let car4 = Video(image: Images.tesl, title: "Tesla Roadster")
        let car5 = Video(image: Images.lam20, title: "Lambo")
        let car6 = Video(image: Images.audi20, title: "audi")
        let car7 = Video(image: Images.volv20, title: "Volvo Polestar")
        let car8 = Video(image: Images.prsc20, title: "Porsce Taycan")
        let car9 = Video(image: Images.buga20, title: "Buggati")
        let car10 = Video(image: Images.ferr20, title: "Ferrari")
        
        return [car1, car2, car3, car4, car5, car6, car7, car8, car9, car10]
    }
}
