//
//  Video.swift
//  MyTableView
//
//  Created by Field Employee on 12/9/21.
//

import UIKit

struct Video {
    var image: UIImage
    var title: String
}
