//
//  Constants.swift
//  MyTableView
//
//  Created by Field Employee on 12/9/21.
//

import UIKit

struct Images {
    static let ast19 = UIImage(named: "2019AstonMartinDBSSuperleggera.jpeg")!
    static let merc20 = UIImage(named: "2020MercedesAMGGT63SFourDoor.jpeg")!
    static let bent20 = UIImage(named: "2020BentleyContinentalGTConvertible.jpeg")!
    static let tesl = UIImage(named: "Tesla-Roadster.jpeg")!
    static let lam20 = UIImage(named: "2020LamborghiniAventadorSVJRoadster.jpeg")!
    static let audi20 = UIImage(named: "2020AudiRS6Avant.jpeg")!
    static let volv20 = UIImage(named: "2020VolvoPolestar1.jpeg")!
    static let prsc20 = UIImage(named: "2020PorscheTaycanMissionEConcept.jpeg")!
    static let buga20 = UIImage(named: "2020BugattiChironSuperSport300.jpeg")!
    static let ferr20 = UIImage(named: "2020ferrariSF90Stradale.jpeg")!
}
